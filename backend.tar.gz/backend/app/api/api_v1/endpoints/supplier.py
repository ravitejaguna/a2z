import asyncio
from typing import Any, Optional
import pandas as pd
import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app import crud
from app.api import deps
from app import schemas
from app.models.user import Users
from app.models.supplier import SupplierData

router = APIRouter()



@router.get("/my-ucid-serach/", status_code=200, response_model=schemas.SupplierDataSearchResults)
def fetch_user_SupplierData(
    *,
    db: Session = Depends(deps.get_db),
    current_user: Users = Depends(deps.get_current_user),
) -> Any:
    """
    Fetch all SupplierDatas for a user
    """
    feedbacks = current_user.feedbacks
    if not feedbacks:
        return {"results": list()}

    return {"results": list(feedbacks)}




@router.post("/", status_code=201, response_model=schemas.SupplierData)
def create_SupplierData(
    *,
    SupplierData_in: schemas.SupplierDataCreate,
    db: Session = Depends(deps.get_db),
    current_user: Users = Depends(deps.get_current_user),
) -> Any:
    """
    Create a new SupplierData in the database.
    """
    uc_ids = ['basics_1a','changes_1b','intesive_2']

    if SupplierData_in.uc_id not in uc_ids:
        raise HTTPException(
            status_code=403, detail=f"The Provided uc_id not exists"
        )
    
    if SupplierData_in.submitter_id != current_user.id:
        raise HTTPException(
            status_code=403, detail=f"You can only submit SupplierData as yourself"
        )
    
    df_list = []
    for s in db.query(SupplierData).all():
        ss = vars(s)
        ss.pop('_sa_instance_state')
        ss = ss['data']
        df_list.append(ss)
    df_list = [element for innerList in df_list for element in innerList]
      

    check = any(item in SupplierData_in.data for item in df_list)
    print(check)

    basics_1a_keys = {"ID_part","ZGS","kpi_process_step","ID_kpi","kpi_value","date_time","batch","container"}
    changes_1b_keys = {"ID_part","ZGS","ID_change","date_time_report","date_time_changestart","date_time_changeend","ID_feature"}
    intensive_2_keys = {"ID_part","ZGS","kpi_process_step","ID_kpi","kpi_value","date_time","batch","container"}
    
    sup_data_keys = set().union(*(d.keys() for d in SupplierData_in.data))
    print(sup_data_keys)
    if SupplierData_in.uc_id == 'basics_1a' and sup_data_keys != basics_1a_keys:
         raise HTTPException(
            status_code=403, detail=f"The Subimitted Data is not in desired format for basics_1a, please review your data model request"
        )
    if SupplierData_in.uc_id == 'changes_1b' and sup_data_keys != changes_1b_keys:
         raise HTTPException(
            status_code=403, detail=f"The Subimitted Data is not in desired format for changes_1b, please review your data model request"
        )
    if SupplierData_in.uc_id == 'intensive_2' and sup_data_keys != intensive_2_keys:
         raise HTTPException(
            status_code=403, detail=f"The Subimitted Data is not in desired format for intensive_2, please review your data model request"
        )
    
    
    if check:
        raise HTTPException(
            status_code=403, detail=f"The Subimitted Data is Already Exists"
        )
    
    supplier_data = crud.supplierdata.create(db=db, obj_in=SupplierData_in)

    return supplier_data

