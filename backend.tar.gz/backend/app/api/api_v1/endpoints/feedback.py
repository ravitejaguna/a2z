import asyncio
from typing import Any, Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app import crud
from app.api import deps
from app.schemas.feedback import (
    Feedback,
    FeedbackCreate,
    FeedbackSearchResults
)
from app.models.user import Users
#from app.models.feedback import Feedback

router = APIRouter()



@router.get("/my-feedbacks/", status_code=200, response_model=FeedbackSearchResults)
def fetch_user_feedbacks(
    *,
    db: Session = Depends(deps.get_db),
    current_user: Users = Depends(deps.get_current_user),
) -> Any:
    """
    Fetch all feedbacks for a user
    """
    feedbacks = current_user.feedbacks
    if not feedbacks:
        return {"results": list()}

    return {"results": list(feedbacks)}




@router.post("/", status_code=201, response_model=Feedback)
def create_feedback(
    *,
    feedback_in: FeedbackCreate,
    db: Session = Depends(deps.get_db),
    current_user: Users = Depends(deps.get_current_user),
) -> Any:
    """
    Create a new feedback in the database.
    """
    if feedback_in.submitter_id != current_user.id:
        raise HTTPException(
            status_code=403, detail=f"You can only submit feedback as yourself"
        )
    feed_back = crud.feedback.create(db=db, obj_in=feedback_in)

    return feed_back

