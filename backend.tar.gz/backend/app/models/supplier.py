from sqlalchemy import Column, Integer, String, ForeignKey,JSON
from sqlalchemy.orm import relationship

from app.db.base_class import Base


class SupplierData(Base):
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(String(256), nullable=False)
    uc_id = Column(String(256), nullable=False)
    data = Column(JSON, nullable=False)
    submitter_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    sup_upload = relationship("Users", back_populates="supplieruploads")
