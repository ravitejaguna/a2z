from sqlalchemy import Integer, String, Column, Boolean
from sqlalchemy.orm import relationship

from app.db.base_class import Base


class Users(Base):
    id = Column(Integer, primary_key=True, index=True)
    supplier_id = Column(String(256),nullable=False)
    supplier_name = Column(String(256), nullable=True)
    email = Column(String, index=True, nullable=False)
    is_superuser = Column(Boolean, default=False)
    # New addition
    hashed_password = Column(String, nullable=False)
    feedbacks = relationship(
        "Feedback",
        cascade="all,delete-orphan",
        back_populates="submitter"
    )
    supplieruploads = relationship("SupplierData", back_populates="sup_upload")

    