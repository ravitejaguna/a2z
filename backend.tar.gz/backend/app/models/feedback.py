from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from app.db.base_class import Base


class Feedback(Base):
    id = Column(Integer, primary_key=True, index=True)
    product = Column(String(256), nullable=False)
    comments = Column(String(256), nullable=False)
    timestamp = Column(String(256), nullable=False)
    submitter_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    submitter = relationship("Users", back_populates="feedbacks")
    