from pydantic import BaseModel, HttpUrl
from typing import Optional
from typing import Sequence


class FeedbackBase(BaseModel):
    product: Optional[str]
    comments: Optional[str]
    timestamp: Optional[str]
    class Config:
        orm_mode = True
        allow_population_by_field_name = True
        arbitrary_types_allowed = True


class FeedbackCreate(FeedbackBase):  
    
    submitter_id: int

    class Config:
        orm_mode = True
        allow_population_by_field_name = True
        arbitrary_types_allowed = True




# Properties shared by models stored in DB
class FeedbackInDBBase(FeedbackBase):
    id: Optional[int] = None


    class Config:
        orm_mode = True


# Properties to return to client
class Feedback(FeedbackInDBBase):
    ...


# Properties properties stored in DB
class FeedbackInDB(FeedbackInDBBase):
    ...


class FeedbackSearchResults(BaseModel):
    results: Sequence[Feedback]
