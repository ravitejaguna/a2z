from pydantic import BaseModel, HttpUrl
from typing import Optional
from typing import Sequence


class SupplierDataBase(BaseModel):
    timestamp: Optional[str]
    uc_id: Optional[str]
    data: list = []
    class Config:
        orm_mode = True
        allow_population_by_field_name = True
        arbitrary_types_allowed = True


class SupplierDataCreate(SupplierDataBase):  
    
    submitter_id: int

    class Config:
        orm_mode = True
        allow_population_by_field_name = True
        arbitrary_types_allowed = True




# Properties shared by models stored in DB
class SupplierDataInDBBase(SupplierDataBase):
    id: Optional[int] = None


    class Config:
        orm_mode = True


# Properties to return to client
class SupplierData(SupplierDataInDBBase):
    ...


# Properties properties stored in DB
class SupplierDataInDB(SupplierDataInDBBase):
    ...


class SupplierDataSearchResults(BaseModel):
    results: Sequence[SupplierData]
