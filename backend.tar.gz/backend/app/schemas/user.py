from typing import Optional

from pydantic import BaseModel, EmailStr


class UsersBase(BaseModel):
    supplier_id: Optional[str]
    supplier_name: Optional[str]
    email: Optional[EmailStr] = None
    is_superuser: bool = False


# Properties to receive via API on creation
class UsersCreate(UsersBase):
    email: EmailStr
    password: str


# Properties to receive via API on update
class UsersUpdate(UsersBase):
    ...


class UserInDBBase(UsersBase):
    id: Optional[int] = None

    class Config:
        orm_mode = True


# Additional properties stored in DB but not returned by API
class UserInDB(UserInDBBase):
    hashed_password: str


# Additional properties to return via API
class Users(UserInDBBase):
    ...
