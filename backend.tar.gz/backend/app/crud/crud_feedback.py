from typing import Any, Dict, Optional, Union
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from datetime import datetime
from app.crud.base import CRUDBase
from app.models.feedback import Feedback
from app.models.user import Users
from app.schemas.feedback import FeedbackCreate,FeedbackSearchResults
now = datetime.now()




class CRUDFeedback(CRUDBase[Feedback,FeedbackCreate,FeedbackSearchResults]):
    

    def create(self, db: Session, *,obj_in: FeedbackCreate) -> Feedback:
        
        create_data = obj_in.dict()
        
        db_obj = Feedback(**create_data)
        
        print(db_obj)
        db.add(db_obj)
        db.commit()

        return db_obj


feedback = CRUDFeedback(Feedback)

