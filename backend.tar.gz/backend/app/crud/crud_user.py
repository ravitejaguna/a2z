from typing import Any, Dict, Optional, Union

from sqlalchemy.orm import Session

from app.crud.base import CRUDBase
from app.models.user import Users
from app.schemas.user import UsersCreate, UsersUpdate
from app.core.security import get_password_hash


class CRUDUser(CRUDBase[Users, UsersCreate, UsersUpdate]):
    def get_by_email(self, db: Session, *, email: str) -> Optional[Users]:
        return db.query(Users).filter(Users.email == email).first()

    def create(self, db: Session, *, obj_in: UsersCreate) -> Users:
        create_data = obj_in.dict()
        create_data.pop("password")
        db_obj = Users(**create_data)
        db_obj.hashed_password = get_password_hash(obj_in.password)
        db.add(db_obj)
        db.commit()

        return db_obj

    def update(
        self, db: Session, *, db_obj: Users, obj_in: Union[UsersUpdate, Dict[str, Any]]
    ) -> Users:
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)

        return super().update(db, db_obj=db_obj, obj_in=update_data)

    def is_superuser(self, user: Users) -> bool:
        return user.is_superuser


user = CRUDUser(Users)
