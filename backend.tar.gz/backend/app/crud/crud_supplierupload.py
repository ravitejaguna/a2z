from typing import Any, Dict, Optional, Union
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from datetime import datetime
from app.crud.base import CRUDBase
from app.models.supplier import SupplierData
from app.models.user import Users
from app.schemas.supplierupload import SupplierDataCreate,SupplierDataSearchResults
now = datetime.now()




class CRUDSupplierData(CRUDBase[SupplierData,SupplierDataCreate,SupplierDataSearchResults]):
    

    def create(self, db: Session, *,obj_in: SupplierDataCreate) -> SupplierData:

        create_data = obj_in.dict()
        
        #print(create_data)
        
        db_obj = SupplierData(**create_data)
        
        
        db.add(db_obj)
        db.commit()

        return db_obj


supplierdata = CRUDSupplierData(SupplierData)

