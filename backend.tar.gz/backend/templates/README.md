# QM Weibull

This folder will have index.html file from FE during CI/CD Piepline deployement
